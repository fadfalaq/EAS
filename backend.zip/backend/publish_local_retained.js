const mqtt = require('mqtt');
const broker = 'ws://localhost:8085';
const topic = 'UTS-pemrograman-iot/fadhail';

const client = mqtt.connect(broker, { clientId: 'local_test_retained_' + Math.random().toString(16).slice(2), connectTimeout: 5000, reconnectPeriod: 0 });

client.on('connect', () => {
  console.log('connected to local bridge, publishing RETAINED test message to', topic);
  const msg = JSON.stringify({ suhu: 29.9, humidity: 53.1, lux: 120.3, from: 'local_test_retained' });
  client.publish(topic, msg, { qos: 0, retain: true }, (err) => {
    if (err) console.error('publish err', err);
    else console.log('published retained:', msg);
    client.end();
  });
});

client.on('error', (e) => {
  console.error('connection error', e && e.message ? e.message : e);
  client.end();
});
