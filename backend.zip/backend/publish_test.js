// simple MQTT publisher test to broker.emqx.io via websocket
const mqtt = require('mqtt');
const broker = 'wss://broker.emqx.io:8084/mqtt';
const topic = 'sensor/data';

const client = mqtt.connect(broker, { clientId: 'test_publisher_' + Math.random().toString(16).slice(2) });

client.on('connect', () => {
  console.log('connected to broker, publishing test message to', topic);
  const msg = JSON.stringify({ suhu: 27.5, humidity: 45.6, lux: 12.3, from: 'test' });
  client.publish(topic, msg, { qos: 0 }, (err) => {
    if (err) console.error('publish err', err);
    else console.log('published:', msg);
    client.end();
  });
});

client.on('error', (e) => {
  console.error('connection error', e);
});
