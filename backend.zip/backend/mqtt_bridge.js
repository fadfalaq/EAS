// MQTT bridge: local WebSocket MQTT broker that forwards to upstream MQTT over TLS
// Usage:
// 1) npm install aedes websocket-stream mqtt
// 2) node mqtt_bridge.js

const aedes = require('aedes')();
const http = require('http');
const websocket = require('websocket-stream');
const mqtt = require('mqtt');

// Local WebSocket port (browser will connect here)
const LOCAL_WS_PORT = 8085;
// Upstream broker (MQTT over TLS)
const UPSTREAM_URL = 'mqtts://broker.mqtt.cool:8883';
// If your upstream requires auth, set these
const UPSTREAM_USERNAME = '';
const UPSTREAM_PASSWORD = '';

// Create local aedes broker with websocket server
const server = http.createServer();
websocket.createServer({ server: server }, aedes.handle);
server.listen(LOCAL_WS_PORT, () => {
  console.log(`Local MQTT over WS broker listening on ws://localhost:${LOCAL_WS_PORT}`);
});

// Connect to upstream MQTT (TLS)
const upstreamOpts = {
  clientId: 'bridge_upstream_' + Math.random().toString(16).substr(2, 8),
  reconnectPeriod: 5000,
  rejectUnauthorized: false, // allow self-signed for testing
};
if (UPSTREAM_USERNAME) upstreamOpts.username = UPSTREAM_USERNAME;
if (UPSTREAM_PASSWORD) upstreamOpts.password = UPSTREAM_PASSWORD;

const upstream = mqtt.connect(UPSTREAM_URL, upstreamOpts);

upstream.on('connect', () => {
  console.log('Connected to upstream broker:', UPSTREAM_URL);
  // subscribe to everything (or restrict to topics you need)
  upstream.subscribe('#', { qos: 0 }, (err) => {
    if (err) console.error('Upstream subscribe error', err);
    else console.log('Subscribed upstream to #');
  });
});

upstream.on('error', (err) => {
  console.error('Upstream error', err && err.message ? err.message : err);
});

upstream.on('message', (topic, payload) => {
  // forward upstream -> local broker
  // publish into aedes so local clients see it
  aedes.publish({ topic: topic, payload: payload, qos: 0 }, (err) => {
    if (err) console.error('aedes publish error', err);
    else console.log('Bridged upstream -> local:', topic, payload.toString().slice(0,80));
  });
});

// Forward local client publishes to upstream (client != null means a local client published)
aedes.on('publish', (packet, client) => {
  if (client) {
    // avoid forwarding our own bridge messages (client === null for server-originated publishes)
    upstream.publish(packet.topic, packet.payload, { qos: 0 }, (err) => {
      if (err) console.error('Forward to upstream failed', err);
      else console.log('Forwarded local -> upstream:', packet.topic, packet.payload.toString().slice(0,80));
    });
  }
});

console.log('MQTT bridge starting...');
