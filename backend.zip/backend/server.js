require('dotenv').config();
const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// Buat koneksi ke database (pool)
const pool = mysql.createPool({
  host: process.env.DB_HOST,
  port: parseInt(process.env.DB_PORT, 10) || 3306,
  user: process.env.DB_USER,
  password: process.env.DB_PASS,
  database: process.env.DB_NAME,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// Health check
app.get('/', (req, res) => res.json({ status: 'ok' }));

// Endpoint untuk mengambil semua data sensor
app.get('/api/data', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM data_sensor ORDER BY timestamp DESC');
    res.json(rows);
  } catch (err) {
    console.error('DB error GET /api/data', err);
    res.status(500).json({ message: 'Terjadi kesalahan server' });
  }
});

// Endpoint untuk menambahkan data baru
app.post('/api/data', async (req, res) => {
  let { suhu, humidity, lux } = req.body;

  // basic validation and conversion to numbers
  suhu = suhu === undefined ? null : Number(suhu);
  humidity = humidity === undefined ? null : Number(humidity);
  lux = lux === undefined ? null : Number(lux);

  if (
    suhu === null || Number.isNaN(suhu) ||
    humidity === null || Number.isNaN(humidity) ||
    lux === null || Number.isNaN(lux)
  ) {
    return res.status(400).json({ message: 'Invalid payload: suhu, humidity, lux required and must be numbers' });
  }

  try {
    await pool.execute(
      'INSERT INTO data_sensor (suhu, humidity, lux) VALUES (?, ?, ?)',
      [suhu, humidity, lux]
    );
    res.json({ message: 'Data berhasil disimpan' });
  } catch (err) {
    console.error('DB error POST /api/data', err);
    res.status(500).json({ message: 'Gagal menyimpan data' });
  }
});

const PORT = parseInt(process.env.PORT, 10) || 3000;
app.listen(PORT, () => console.log(`✅ Server berjalan di http://localhost:${PORT}`));
