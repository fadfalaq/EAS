const mqtt = require('mqtt');
const broker = 'wss://broker.mqtt.cool:8084/mqtt'; // try with /mqtt path
const client = mqtt.connect(broker, {
  clientId: 'test_mqtt_cool_' + Math.random().toString(16).slice(2),
  connectTimeout: 10000,
  reconnectPeriod: 0,
  rejectUnauthorized: false
});

console.log('Attempting connect to', broker);

client.on('connect', () => {
  console.log('CONNECTED');
  client.end(true);
});
client.on('error', (err) => {
  console.error('ERROR', err && err.message ? err.message : err);
  client.end(true);
});
client.on('close', () => console.log('CLOSED'));
client.on('offline', () => console.log('OFFLINE'));
client.on('end', () => console.log('END'));
