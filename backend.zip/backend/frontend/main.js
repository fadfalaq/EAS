// MQTT config
// If your broker supports WebSocket over TLS, use wss://hostname:port
// Update the URL/port if your broker uses different WebSocket port.
// Use local bridge (ws) for browsers when upstream broker doesn't expose WSS.
// After starting mqtt_bridge.js, point the frontend to ws://localhost:8085
const MQTT_BROKER = "ws://localhost:8085"; // local bridge endpoint
const MQTT_USERNAME = ""; // leave empty for anonymous connect
const MQTT_PASSWORD = ""; // leave empty for anonymous connect
// Match the topics shown in your broker UI (subscribe to control, publish to base topic)
const SENSOR_TOPIC = "UTS-pemrograman-iot/fadhail"; // topic published by device (matches your Publish field)
const POMPA_TOPIC = "UTS-pemrograman-iot/fadhail/control"; // topic to control device (matches Subscribed topics)

let client;
let statusPompa = "--";

// Debug logger
function debugLog(msg) {
  const timestamp = new Date().toLocaleTimeString();
  const logText = `[${timestamp}] ${msg}`;
  console.log(logText);
  const debugEl = document.getElementById('debug-log');
  if (debugEl) {
    debugEl.textContent = (debugEl.textContent || '') + logText + '\n';
    debugEl.scrollTop = debugEl.scrollHeight; // auto scroll
  }
}

function updateMQTTStatus(status) {
  const statusEl = document.getElementById('mqtt-status');
  if (statusEl) {
    statusEl.textContent = `MQTT Status: ${status}`;
    statusEl.style.color = status === 'CONNECTED' ? '#22c55e' : status === 'DISCONNECTED' ? '#dc2626' : '#666';
  }
}

function updateSensorUI({ suhu, humidity, lux }) {
  document.getElementById("suhu").textContent = suhu !== undefined ? `${suhu} °C` : "-- °C";
  document.getElementById("humidity").textContent = humidity !== undefined ? `${humidity} %` : "-- %";
  document.getElementById("lux").textContent = lux !== undefined ? `${lux} %` : "-- %";
}

function updatePompaUI(status) {
  statusPompa = status;
  document.getElementById("status-pompa").textContent = `Status Pompa: ${status}`;
}

function connectMQTT(brokerUrl = MQTT_BROKER, username = MQTT_USERNAME, password = MQTT_PASSWORD) {
  const clientId = `webclient_${Math.random().toString(16).substr(2, 8)}`;
  const opts = {
    clientId,
    keepalive: 30,
    clean: true,
    reconnectPeriod: 3000, // tunggu 3 detik sebelum reconnect
    connectTimeout: 10 * 1000, // timeout 10 detik
    rejectUnauthorized: false, // untuk SSL/TLS self-signed certificates
  };
  
  // hanya set username/password jika tidak kosong
  if (username && username.trim()) opts.username = username;
  if (password && password.trim()) opts.password = password;

  debugLog(`Connecting: broker=${brokerUrl}, clientId=${clientId}, auth=${username ? 'yes' : 'no'}`);
  client = mqtt.connect(brokerUrl, opts);

  client.on('connect', () => {
    debugLog('✅ MQTT connected successfully!');
    updateMQTTStatus('CONNECTED');
    updatePompaUI('CONNECTED');
    // subscribe to topics
    client.subscribe(SENSOR_TOPIC, { qos: 0 }, (err) => {
      if (err) {
        debugLog('❌ Subscribe sensor topic failed: ' + err);
      } else {
        debugLog('✓ Subscribed to: ' + SENSOR_TOPIC);
      }
    });
    client.subscribe(POMPA_TOPIC, { qos: 0 }, (err) => {
      if (err) {
        debugLog('❌ Subscribe pompa topic failed: ' + err);
      } else {
        debugLog('✓ Subscribed to: ' + POMPA_TOPIC);
      }
    });
  });

  client.on('reconnect', () => {
    debugLog('🔄 MQTT reconnecting...');
    updateMQTTStatus('RECONNECTING');
  });

  client.on('error', (err) => {
    const errMsg = err.message || JSON.stringify(err);
    debugLog('❌ MQTT error: ' + errMsg);
    updateMQTTStatus('DISCONNECTED');
    updatePompaUI('DISCONNECTED');
  });

  client.on('message', (topic, message) => {
    try {
      const payload = message.toString();
      debugLog(`📨 Message from ${topic}: ${payload.substring(0, 50)}`);
      if (topic === SENSOR_TOPIC) {
        // expect JSON payload from sensor
        try {
          const data = JSON.parse(payload);
          updateSensorUI(data);
        } catch (e) {
          // if payload is CSV or plain numbers, try parse
          debugLog('⚠️ Cannot parse sensor JSON: ' + payload);
        }
      } else if (topic === POMPA_TOPIC) {
        updatePompaUI(payload);
      }
    } catch (e) {
      debugLog('❌ Error handling message: ' + e.message);
    }
  });
}

document.getElementById('btn-on').onclick = () => {
  if (client && client.connected) {
    client.publish(POMPA_TOPIC, 'ON');
    updatePompaUI('ON');
  } else {
    alert('MQTT client not connected');
  }
};

document.getElementById('btn-off').onclick = () => {
  if (client && client.connected) {
    client.publish(POMPA_TOPIC, 'OFF');
    updatePompaUI('OFF');
  } else {
    alert('MQTT client not connected');
  }
};

// Start connection to custom EMQX broker. If you have username/password, set them in constants above.
debugLog('🚀 Starting MQTT connection...');
connectMQTT();
